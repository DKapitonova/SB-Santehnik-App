//
//  WelcomeViewController.swift
//  SB-Santehnik-App
//
//  Created by Daria on 19.01.2022.
//

import UIKit

class WelcomeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

}
