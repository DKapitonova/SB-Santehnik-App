//
//  Onboarding.swift
//  SB-Santehnik-App
//
//  Created by Daria on 19.01.2022.
//

import Foundation
import UIKit

class OnboardingViewController: UIViewController {
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var pageControl: UIPageControl!

    var slides:  [OnboardingSlide] = [ ]
  
    override func viewDidLoad() {
        super.viewDidLoad()
        
        slides = [ OnboardingSlide(title: "Быстро и удобно", description: "Бесплатный приезд и оценка стоимости мастером в течение 45 минут", image: UIImage(named: "onboarding2")!),
                   OnboardingSlide(title: "Проверено", description: "Более 9 лет опыта работы в сфере сантехники", image: UIImage(named: "onboarding3")!),
                   OnboardingSlide(title: "Надежно", description: "Предоставляем гарантию на все виды\nуслуг до 3 лет", image: UIImage(named: "onboarding4")!),
                   
        ]
        
        
        nextButton.layer.cornerRadius = 30
        
    }
    
    
    @IBAction func nextButtonClicked(_ sender: UIButton) {
    }
    
    }
extension OnboardingViewController : UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: OnboardingCollectionViewCell.identifier, for: indexPath) as! OnboardingCollectionViewCell
        
        cell.setup(slides[indexPath.row])
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        slides.count
    }
    
    
    
}

/*  let button2 = UIButton(type: .system)
 button2.setTitle("Все >", for: .normal)
 contentView.addSubview(button2)
 button2.snp.makeConstraints{ maker in
     maker.right.equalTo(contentView).inset(33)
     maker.top.equalTo(contentView).inset(793)
 }
 
  let h6 = UILabel(frame: CGRect(x: 20, y: 999, width: 335, height: 28))
  h6.text = "Мастер на час"
  h6.font = UIFont(name: "Gerbera-Bold", size: 24)
  contentView.addSubview(h6)
 */
